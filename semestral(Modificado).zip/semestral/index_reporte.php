<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
include_once 'connect_db.php';

$db = new Conect_MySql();

//en  caso de que no existe
$id = isset($_POST['Id']) ? $_POST['Id']:'';
$fe_Re = isset($_POST['Fecha de Reporte']) ? $_POST['Fecha de Reporte'] : '';
$Ti = isset($_POST['Titutlo']) ? $_POST['Titutlo'] : '';
$Desp = isset($_POST['Despcricion']) ? $_POST['Despcricion'] :'';
$N_Rep =  isset($_POST['Numero de Reporte']) ? $_POST['Numero de Reporte'] :'';
$Cod_Depar = isset($_POST['Codigo del Departamento']) ? $_POST['Codigo del Departamento'] :'';

//llamamos el procedimiento almacenado
$sql = "CALL sp_reporte('$id','$fe_Re','$Ti','$Desp','$N_Rep','$Cod_Depar');";

//echo $sql;exit;
//lo ejecutamos
$array = $db->execute($sql);
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="container">
            <h1></h1>
            <div class="row">
                <div class="col-lg-6 col-md-offset-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">Reporte</div>
                        <div class="panel-body">
                            <form class="form-horizontal" action="." method="POST">
                              <div class="form-group">
                                  <label class="col-sm-4 control-label">Id del Producto</label>
                                  <div class="col-sm-8">
                                      <input type="text" class="form-control" name="Id" id="Id">
                                  </div>
                              </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Fecha de Reporte</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="Fecha de Reporte" id="Fecha de Reporte">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Titutlo</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="Titutlo" id="Titutlo">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Despcricion</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="Despcricion" id="Despcricion">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Numero de Reporte</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="Numero de Reporte" id="Numero de Reporte">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Codigo del Departamento</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="Codigo del Departamento" id="Codigo del Departamento">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-4 control-label"></label>
                                    <div class="col-sm-8">
                                        <button type="submit" class="btn btn-default">Buscar</button>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>


                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-offset-3">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                              //el cabezado de las tablas
                                <tr>
                                    <th>id</th>
                                    <th>fecha_de_report</th>
                                    <th>titulo_repot</th>
                                    <th>descricion</th>
                                    <th>numero_repot</th>
                                    <th>codig_dep</th>
                                </tr>
                            </thead>
                            <tbody>
                              //los valores de las tablas
                                        <td><?php echo $value['Id']; ?></td>
                                        <td><?php echo $value['Fecha de Reporte']; ?></td>
                                        <td><?php echo $value['Titutlo']; ?></td>
                                        <td><?php echo $value['Despcricion']; ?></td>
                                        <td><?php echo $value['Numero de Reporte']; ?></td>
                                        <td><?php echo $value['Codigo del Departamento']; ?></td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
