<?php
// Include config file
require_once "connect_db.php";
// Define variables and initialize with empty values
$Id = $Nombre = $Codigo_prod = $Cantidad = $Codig_categ = "";
$Id_err = $Nombre_err = $Codigo_prod_err = $Cantidad_err = $Codig_categ_err = "";

// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $Id = $_POST["id"];

    // Validando nombre
    $input_Nombre = trim($_POST["nombre"]);
    if(empty($input_Nombre)){
        $Nombre_err = "Porfavor introduzca un nombre.";
    } else{
        $Nombre = $input_Nombre;
    }

    // Validando fecha de prestamo
    $input_Codigo_prod = trim($_POST["codigo_prod"]);
    if(empty($input_Codigo_prod)){
        $Codigo_prod_err = "Porfavor introduzca un codigo.";
    } else{
        $Codigo_prod = $input_Codigo_prod;
    }
    // validando nombre de persona
    $input_Cantidad= trim($_POST["cantidad"]);
    if(empty($input_Cantidad)){
        $Cantidad_err = "Porfavor introduzca una Cantidad.";
    }else{
        $Cantidad = $input_Cantidad;
    }
    // validando fecha de entrega del equipo prestado
    $input_codig_categ = trim($_POST["codig_categ"]);
    if(empty($input_codig_categ)){
        $codig_categ_err = "Porfavor introduzca un codigo.";
    } else{
        $Codig_categ = $input_codig_categ;
    }

    // Check input errors before inserting in database
    if(empty($Nombre_err) && empty($codigo_prod_err)&& empty($cantidad_err) && empty($codig_categ_err)){
        // Prepare an update statement
        $sql = "UPDATE productos set nombre =?, cod_prod =?, cantidad =?, codig_categ =? where id=?";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssi", $param_Nombre, $param_codigo_prod, $param_cantidad,$param_codig_categ,$param_id);

            // Set parameters

            $param_Nombre = $Nombre;
            $param_codigo_prod = $Codigo_prod;
            $param_cantidad= $Cantidad;
            $param_codig_categi= $Codig_categ;
            $param_id = $Id;


            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: producto.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);

        // Prepare a select statement
        $sql = "SELECT * FROM productos where id = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_id);

            // Set parameters
            $param_id = $id;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);

                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

                    // Retrieve individual field value
                    $Id = $row["id"];
                    $Nombre = $row["nombre"];
                    $Codigo_prod = $row["codigo_prod"];
                    $Cantidad = $row["cantidad"];
                    $Codig_categ = $row["codig_categ"];
         
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }

            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);

        // Close connection
        mysqli_close($link);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ACTUALIZAR PRODUCTOS</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>ACTUALIZAR PRODUCTOS</h2>
                    </div>
                    <p>Por favor, edite los valores de entrada y envíe para actualizar el registro..</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                      <div class="form-group <?php echo (!empty($Id)) ? 'has-error' : ''; ?>">
                      <label>Id</label>
                      <input type="text" name="id" class="form-control" value="<?php echo $Id; ?>">
                      <span class="help-block"><?php echo $Id_err;?></span>
                      </div>
                      <div class="form-group <?php echo (!empty($Nombre)) ? 'has-error' : ''; ?>">
                      <label>Nombre</label>
                      <input type="text" name="nombre" class="form-control" value="<?php echo $Nombre; ?>">
                      <span class="help-block"><?php echo $Nombre_err;?></span>
                    </div>
                      <div class="form-group <?php echo (!empty($Codigo_prod)) ? 'has-error' : ''; ?>">
                      <label>Codigo de producto</label>
                      <input type="text" name="codigo_prod" class="form-control" value="<?php echo $Codigo_prod; ?>">
                      <span class="help-block"><?php echo $Codigo_prod_err;?></span>
                    </div>
                    </div>
                    <div class="form-group <?php echo (!empty($Cantidad)) ? 'has-error' : ''; ?>">
                    <label>Cantidad</label>
                    <input type="text" name="cantidad" class="form-control" value="<?php echo $Cantidad; ?>">
                    <span class="help-block"><?php echo $Cantidad_err;?></span>
                    </div>
                    </div>
                    <div class="form-group <?php echo (!empty($Codig_categ)) ? 'has-error' : ''; ?>">
                    <label>Codigo categoria</label>
                    <input type="text" name="codig_categ" class="form-control" value="<?php echo $Codig_categ; ?>">
                    <span class="help-block"><?php echo $Codig_categ_err;?></span>
                    </div>
                    </div>
                        <input type="hidden" name="id" value="<?php echo $Id; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="admin.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
