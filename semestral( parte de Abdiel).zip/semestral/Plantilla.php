
<?php
//Agregamos una Libreria
	require 'fpdf/fpdf.php';
// se trabaja con la clase PDF y Haceemos una Herencia a FPDF
	class PDF extends FPDF
	{
		function Header()
		{
			//Para colocar una imagen para la pagi como un logo
			$this->Image('Imagenes/compras-on-line', 5, 5, 30 );
			//La Fuente de la letra
			$this->SetFont('Arial','B',15);
			//Tamano
			$this->Cell(30);
			$this->Cell(120,10, 'Reportes de Compras',0,0,'C');
			//Salto de linea
			$this->Ln(20);
		}

//El Pie de la Pagina
		function Footer()
		{
			//Tamano del pie de pagina
			$this->SetY(-15);
			//Fuente del pie de pagina
			$this->SetFont('Arial','I', 8);
			$this->Cell(0,10, 'Pagina '.$this->PageNo().'/{nb}',0,0,'C' );
		}
	}
?>
