<?php


extract($_POST1);    //extraer todos los valores del metodo post del formulario de actualizar
    require("connect_db.php");
    $sentencia="update productos set nombre ='$nombre', cod_prod ='$cod_prod', cantidad ='$cantidad', codig_categ ='$codig_categ' where id='$id'";
    //la variable  $mysqli viene de connect_db que lo traigo con el require("connect_db.php");
    $resent=mysqli_query($mysqli,$sentencia);
    if ($resent==null) {
        echo "Error de procesamieno no se han actuaizado los datos";
        echo '<script>alert("ERROR EN PROCESAMIENTO NO SE ACTUALIZARON LOS DATOS")</script> ';
        header("location: producto.php");
        
        echo "<script>location.href='producto.php'</script>";
    }else {
        echo '<script>alert("REGISTRO ACTUALIZADO")</script> ';
        
        echo "<script>location.href='producto.php'</script>";
        
    }
?>